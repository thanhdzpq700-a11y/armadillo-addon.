package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.FoxEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/**
 * Feeds adult foxes sweet or glow berriess (right-click) like a player would:
 * turns smoothly toward the fox, stays within normal reach, needs a
 * clear line of sight, swings the arm, waits a random delay, one at a time.
 *
 * Minecraft 1.21.11 (Yarn). The client can't see love mode / breeding
 * cooldown, so fed foxes are skipped locally for a configurable time.
 */
public class AutoBreedFox extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgHuman = settings.createGroup("Human-like");

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range")
        .description("Max distance to the fox (vanilla reach is 3).")
        .defaultValue(3.0).min(1.0).sliderMax(4.5)
        .build());

    private final Setting<Integer> feedCooldown = sgGeneral.add(new IntSetting.Builder()
        .name("feed-cooldown")
        .description("Seconds to skip an fox after feeding it (love mode lasts 30s).")
        .defaultValue(40).min(5).sliderMax(300)
        .build());

    private final Setting<Integer> maxPerCycle = sgGeneral.add(new IntSetting.Builder()
        .name("max-per-cycle")
        .description("Feedings per round before pausing for the feed cooldown. Keeps a round inside the 30s love window.")
        .defaultValue(20).min(1).sliderMax(50)
        .build());

    private final Setting<Boolean> autoSwap = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-swap")
        .description("Switch to berries (sweet or glow) in your hotbar if you aren't holding one.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> swapBack = sgGeneral.add(new BoolSetting.Builder()
        .name("swap-back")
        .description("Return to the previous hotbar slot after feeding.")
        .defaultValue(true)
        .visible(autoSwap::get)
        .build());

    private final Setting<Boolean> rotate = sgHuman.add(new BoolSetting.Builder()
        .name("smooth-look")
        .description("Turn your camera toward the fox gradually before feeding.")
        .defaultValue(true)
        .build());

    private final Setting<Double> turnSpeed = sgHuman.add(new DoubleSetting.Builder()
        .name("turn-speed")
        .description("Average degrees turned per tick.")
        .defaultValue(14.0).min(3.0).sliderMax(40.0)
        .visible(rotate::get)
        .build());

    private final Setting<Boolean> swing = sgHuman.add(new BoolSetting.Builder()
        .name("swing-hand")
        .description("Play the hand swing animation when feeding.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> lineOfSight = sgHuman.add(new BoolSetting.Builder()
        .name("line-of-sight")
        .description("Only feed foxes you could actually see (no feeding through walls).")
        .defaultValue(true)
        .build());

    private final Setting<Integer> minDelay = sgHuman.add(new IntSetting.Builder()
        .name("min-delay")
        .description("Minimum ticks between feedings.")
        .defaultValue(8).min(1).sliderMax(60)
        .build());

    private final Setting<Integer> maxDelay = sgHuman.add(new IntSetting.Builder()
        .name("max-delay")
        .description("Maximum ticks between feedings.")
        .defaultValue(16).min(1).sliderMax(80)
        .build());

    private final Map<UUID, Long> fedUntil = new HashMap<>();
    private FoxEntity target;
    private int delay;
    private int swapBackIn = -1;
    private int cycleCount;
    private int cycleWait;

    public AutoBreedFox() {
        super(AddonTemplate.CATEGORY, "auto-breed-fox",
            "Feeds nearby foxes berries like a real player so they breed.");
    }

    @Override
    public void onDeactivate() {
        target = null;
        delay = 0;
        cycleCount = 0;
        cycleWait = 0;
        fedUntil.clear();
        if (swapBackIn >= 0) {
            InvUtils.swapBack();
            swapBackIn = -1;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        // Delayed swap back, so the slot doesn't flick back instantly.
        if (swapBackIn >= 0) {
            if (swapBackIn-- == 0) InvUtils.swapBack();
            return;
        }

        if (cycleWait > 0) {
            cycleWait--;
            return;
        }

        if (delay > 0) {
            delay--;
            return;
        }

        long now = mc.world.getTime();
        fedUntil.values().removeIf(until -> until <= now);

        FindItemResult food = InvUtils.findInHotbar(Items.SWEET_BERRIES, Items.GLOW_BERRIES);
        // Without auto-swap, only feed when already holding berries.
        if (!food.found() || (!autoSwap.get() && food.getHand() == null)) {
            target = null;
            return;
        }

        if (target == null || !isValid(target)) target = findTarget();
        if (target == null) return;

        Vec3d aim = aimPoint(target);
        if (rotate.get() && !lookToward(aim)) return; // still turning

        feed(target, aim, food);
    }

    private void feed(FoxEntity fox, Vec3d aim, FindItemResult food) {
        Hand hand = food.getHand();
        boolean swapped = false;

        if (hand == null) {
            if (!autoSwap.get()) return;
            swapped = InvUtils.swap(food.slot(), swapBack.get());
            if (!swapped) return;
            hand = Hand.MAIN_HAND;
        }

        EntityHitResult hit = new EntityHitResult(fox, aim);
        ActionResult result = mc.interactionManager.interactEntityAtLocation(mc.player, fox, hit, hand);
        if (!result.isAccepted()) result = mc.interactionManager.interactEntity(mc.player, fox, hand);
        if (result.isAccepted() && swing.get()) mc.player.swingHand(hand);

        fedUntil.put(fox.getUuid(), mc.world.getTime() + feedCooldown.get() * 20L);
        target = null;

        if (++cycleCount >= maxPerCycle.get()) {
            cycleCount = 0;
            cycleWait = feedCooldown.get() * 20;
        }

        int lo = Math.min(minDelay.get(), maxDelay.get());
        int hi = Math.max(minDelay.get(), maxDelay.get());
        delay = ThreadLocalRandom.current().nextInt(lo, hi + 1);

        if (swapped && swapBack.get()) swapBackIn = 2 + ThreadLocalRandom.current().nextInt(3);
    }

    // ---- targeting ----

    /** Picks the eligible fox with the lowest entity id: a fixed order that also works when many share one block. */
    private FoxEntity findTarget() {
        FoxEntity best = null;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof FoxEntity a) || !isValid(a)) continue;
            if (best == null || a.getId() < best.getId()) best = a;
        }
        return best;
    }

    private boolean isValid(FoxEntity a) {
        if (!a.isAlive() || a.isRemoved() || a.isBaby()) return false;
        if (fedUntil.containsKey(a.getUuid())) return false;

        Vec3d eye = mc.player.getEyePos();
        if (distanceToBox(eye, a.getBoundingBox()) > range.get()) return false;

        if (lineOfSight.get()) {
            RaycastContext ctx = new RaycastContext(eye, aimPoint(a),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player);
            if (mc.world.raycast(ctx).getType() != HitResult.Type.MISS) return false;
        }
        return true;
    }

    private Vec3d aimPoint(Entity e) {
        return e.getBoundingBox().getCenter();
    }

    private double distanceToBox(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.distanceTo(new Vec3d(x, y, z));
    }

    // ---- smooth camera ----

    /** Turns the camera a bit toward the point. Returns true once already aligned. */
    private boolean lookToward(Vec3d aim) {
        Vec3d eye = mc.player.getEyePos();
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;

        float wantYaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float wantPitch = (float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);

        float dYaw = MathHelper.wrapDegrees(wantYaw - mc.player.getYaw());
        float dPitch = wantPitch - mc.player.getPitch();

        if (Math.abs(dYaw) < 3f && Math.abs(dPitch) < 3f) return true;

        ThreadLocalRandom rng = ThreadLocalRandom.current();
        float step = (float) (turnSpeed.get() * (0.6 + rng.nextDouble() * 0.8));
        float pitchStep = step * 0.6f;

        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(dYaw, -step, step));
        mc.player.setPitch(MathHelper.clamp(
            mc.player.getPitch() + MathHelper.clamp(dPitch, -pitchStep, pitchStep), -90f, 90f));
        return false;
    }
}
