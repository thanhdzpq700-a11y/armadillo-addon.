plugins {
    id("fabric-loom") version "1.14-SNAPSHOT"
}

base {
    archivesName.set(properties["archives_base_name"] as String)
}

version = properties["mod_version"] as String
group = properties["maven_group"] as String

repositories {
    mavenCentral()
    maven("https://maven.meteordev.org/releases")
    maven("https://maven.meteordev.org/snapshots")
}

dependencies {
    minecraft("com.mojang:minecraft:${properties["minecraft_version"]}")
    mappings("net.fabricmc:yarn:${properties["yarn_mappings"]}:v2")
    modImplementation("net.fabricmc:fabric-loader:${properties["loader_version"]}")

    // Meteor Client snapshot for the same Minecraft version
    modImplementation("meteordevelopment:meteor-client:${properties["minecraft_version"]}-SNAPSHOT")
}

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}

tasks {
    processResources {
        val propertyMap = mapOf(
            "version" to project.version,
            "minecraft_version" to project.property("minecraft_version"),
            "loader_version" to project.property("loader_version")
        )
        inputs.properties(propertyMap)
        filesMatching("fabric.mod.json") {
            expand(propertyMap)
        }
    }

    withType<JavaCompile> {
        options.release.set(21)
        options.encoding = "UTF-8"
    }
}
