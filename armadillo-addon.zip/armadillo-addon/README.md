# Armadillo Addon (Meteor Client)

A [Meteor Client](https://meteorclient.com) addon for **Minecraft 1.21.11**.
Adds the module **Auto Breed Armadillo**, which feeds spider eyes to nearby
adult armadillos so they enter love mode and breed.

## Behaviour
- Feeds one armadillo at a time, in a fixed order, so armadillos packed into a
  single block are all handled.
- Looks at the armadillo smoothly, stays within normal reach, swings the arm,
  and waits a random delay between feedings.
- Uses spider eyes from the hotbar (auto-swap), optionally swapping back.
- Skips an armadillo for `feed-cooldown` seconds after feeding it (the client
  cannot see love mode or the breeding cooldown).
- `max-per-cycle` limits how many are fed per round before it pauses.

## Settings
| Setting | Default | What it does |
|---|---|---|
| range | 3.0 | Max distance to the armadillo |
| feed-cooldown | 40 | Seconds to skip a fed armadillo |
| max-per-cycle | 20 | Feedings per round before pausing |
| auto-swap / swap-back | on / on | Hotbar switching |
| smooth-look / turn-speed | on / 14 | Gradual camera turn |
| swing-hand | on | Arm swing animation |
| line-of-sight | on | Needs a clear line to the armadillo |
| min-delay / max-delay | 8 / 16 | Random ticks between feedings |

If the armadillos are inside a glass or fenced pen, turn `line-of-sight` off.

## Build
Requires JDK 21.

```
gradle build        # or ./gradlew build if you add the Gradle wrapper
```

The jar is in `build/libs/`. Put it in `mods/` next to
Meteor Client for 1.21.11. Pushing to GitHub also builds it with the included
Actions workflow.

## Updating versions
Edit `gradle.properties` (`minecraft_version`, `yarn_mappings`,
`loader_version`) and the `fabric-loom` version in `build.gradle.kts` to match
the Meteor Client snapshot you target.

Use only where client mods are allowed (singleplayer or servers that permit them).
