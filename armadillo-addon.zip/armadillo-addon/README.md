# Breeding Addon (Meteor Client)

A [Meteor Client](https://meteorclient.com) addon for **Minecraft 1.21.11**.
Adds the module **Auto Breed Fox**, which feeds sweet berries or glow berries to
nearby adult foxes so they enter love mode and breed.

## Behaviour
- Feeds one fox at a time, in a fixed order, so foxes packed into one block are all handled.
- Turns the camera smoothly toward the fox, stays within normal reach, swings the arm,
  and waits a random delay between feedings.
- Uses berries from the hotbar (auto-swap), optionally swapping back.
- Skips a fox for `feed-cooldown` seconds after feeding it (the client cannot see
  love mode or the breeding cooldown).
- `max-per-cycle` limits how many are fed per round before it pauses.

## Settings
| Setting | Default | What it does |
|---|---|---|
| range | 3.0 | Max distance to the fox |
| feed-cooldown | 40 | Seconds to skip a fed fox |
| max-per-cycle | 20 | Feedings per round before pausing |
| auto-swap / swap-back | on / on | Hotbar switching |
| smooth-look / turn-speed | on / 14 | Gradual camera turn |
| swing-hand | on | Arm swing animation |
| line-of-sight | on | Needs a clear line to the fox |
| min-delay / max-delay | 8 / 16 | Random ticks between feedings |

If the foxes are inside a glass or fenced pen, turn `line-of-sight` off.
Wild foxes run from players, so this works best on penned or tamed foxes.

## Build
Requires JDK 21 and Gradle 9.2+. `gradle build`; the jar is in `build/libs/`.
The included GitHub Actions workflow builds it on every push.

Use only where client mods are allowed (singleplayer or servers that permit them).
